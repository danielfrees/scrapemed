import pytest
import scrapemed._parse as _parse

def test_parse():

    #tested by test_paper, unit testing will go here when applicable 
    
    return None